import {readFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
const cfg=JSON.parse(readFileSync('dist/server/wrangler.json','utf8'));
if(!cfg.d1_databases?.[0]?.database_id || cfg.d1_databases[0].database_id==='00000000-0000-4000-8000-000000000000')throw Error('Set SUBGATE_DATABASE_ID to your Cloudflare D1 database ID before building.');
for(const args of [['d1','migrations','apply','DB','--remote','--config','dist/server/wrangler.json'],['deploy','--config','dist/server/wrangler.json']]){const r=spawnSync(process.execPath,['node_modules/wrangler/bin/wrangler.js',...args],{stdio:'inherit'});if(r.status!==0)process.exit(r.status||1)}
