CREATE TABLE `site_visitors` (
	`visitor_id` text PRIMARY KEY NOT NULL,
	`first_seen` integer NOT NULL,
	`last_seen` integer NOT NULL
);
