import LoginForm from '../login-form';
export const dynamic='force-dynamic';
export default function SetupPage(){return <LoginForm setup/>}
