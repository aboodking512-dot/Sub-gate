import {isOwner} from '@/lib/admin-auth';
import {readStore} from '@/lib/store-db';
import AdminEditor from './editor';
import LoginForm from './login-form';
export const dynamic='force-dynamic';
export default async function AdminPage(){try{if(!await isOwner())return <LoginForm/>;const data=await readStore();return <AdminEditor initial={data.store} initialRevision={data.revision}/>;}catch(e){console.error('admin load',e);return <main className="access-page"><h1>تعذّر تحميل لوحة الإدارة</h1><p>حاول مرة ثانية بعد قليل.</p><a href="/admin">إعادة المحاولة</a></main>;}}
