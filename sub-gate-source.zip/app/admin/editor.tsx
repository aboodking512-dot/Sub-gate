"use client";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogAction,
  AlertDialogCancel,
} from "@/components/ui/alert-dialog";
import {
  Plus,
  Save,
  Trash2,
  ExternalLink,
  ImagePlus,
  ArrowUp,
  ArrowDown,
  Check,
  LoaderCircle,
} from "lucide-react";
import { storeSchema, type Store, type Product } from "@/lib/store-model";
export default function AdminEditor({
  initial,
  initialRevision,
}: {
  initial: Store;
  initialRevision: number;
}) {
  const [store, setStore] = useState(initial),
    [revision, setRevision] = useState(initialRevision),
    [saved, setSaved] = useState(JSON.stringify(initial)),
    [busy, setBusy] = useState(false),
    [uploading, setUploading] = useState<string | null>(null),
    [message, setMessage] = useState(""),
    [error, setError] = useState(false),
    [deleting, setDeleting] = useState<string | null>(null),
    [opened, setOpened] = useState<string[]>(
      [initial.products[0]?.id].filter(Boolean),
    ),
    [stats, setStats] = useState<{
      totalVisitors: number;
      activeVisitors: number;
    } | null>(null);
  const dirty = JSON.stringify(store) !== saved;
  const locked = busy || Boolean(uploading);
  useEffect(() => {
    if (!dirty) return;
    const handler = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [dirty]);
  useEffect(() => {
    fetch("/api/admin/stats")
      .then((response) => (response.ok ? response.json() : null))
      .then((data) => {
        if (data && typeof data.totalVisitors === "number") setStats(data);
      })
      .catch(() => {});
  }, []);
  function feedback(text: string, isError = false) {
    setMessage(text);
    setError(isError);
  }
  function update(id: string, patch: Partial<Product>) {
    setStore((s) => ({
      ...s,
      products: s.products.map((p) => (p.id === id ? { ...p, ...patch } : p)),
    }));
    setMessage("");
  }
  function plan(
    id: string,
    index: number,
    patch: Partial<Product["plans"][number]>,
  ) {
    setStore((s) => ({
      ...s,
      products: s.products.map((p) =>
        p.id === id
          ? {
              ...p,
              plans: p.plans.map((v, i) =>
                i === index ? { ...v, ...patch } : v,
              ),
            }
          : p,
      ),
    }));
    setMessage("");
  }
  function add() {
    const id = crypto.randomUUID();
    setStore((s) => ({
      ...s,
      products: [
        ...s.products,
        {
          id,
          name: "اشتراك جديد",
          description: "",
          image: "",
          visible: true,
          plans: [{ label: "شهر", price: 1, oldPrice: 0, note: "" }],
          bundle: {
            enabled: false,
            label: "",
            price: 0,
            oldPrice: 0,
            details: "",
          },
        },
      ],
    }));
    setOpened((o) => [...o, id]);
    setMessage("");
  }
  function move(index: number, direction: number) {
    setStore((s) => {
      const products = [...s.products];
      [products[index], products[index + direction]] = [
        products[index + direction],
        products[index],
      ];
      return { ...s, products };
    });
  }
  async function save() {
    const parsed = storeSchema.safeParse(store);
    if (!parsed.success) {
      setOpened(store.products.map((p) => p.id));
      feedback(
        "راجع الحقول: لكل اشتراك اسم وباقة وسعر أكبر من صفر. رقم الواتساب دولي بدون +. والعرض المفعّل يحتاج عنوان وتفاصيل وسعر.",
        true,
      );
      return;
    }
    setBusy(true);
    feedback("");
    try {
      const r = await fetch("/api/admin/store", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ revision, store: parsed.data }),
      });
      const result = (await r.json()) as {
        error?: string;
        revision: number;
        url: string;
      };
      if (!r.ok) throw Error(result.error || "تعذّر الحفظ.");
      setRevision(result.revision);
      setStore(parsed.data);
      setSaved(JSON.stringify(parsed.data));
      feedback("تم الحفظ. التغييرات ظاهرة الآن في المتجر.");
    } catch (e) {
      feedback(
        e instanceof Error
          ? e.message
          : "تعذّر الاتصال. تغييراتك ما زالت موجودة؛ حاول مرة ثانية.",
        true,
      );
    } finally {
      setBusy(false);
    }
  }
  async function upload(id: string, file?: File) {
    if (!file) return;
    if (
      !["image/png", "image/jpeg", "image/webp"].includes(file.type) ||
      file.size > 2 * 1024 * 1024
    ) {
      feedback("اختار PNG أو JPG أو WebP بحجم أقل من 2 ميغابايت.", true);
      return;
    }
    setUploading(id);
    feedback("");
    try {
      const form = new FormData();
      form.append("image", file);
      const r = await fetch("/api/admin/upload", {
        method: "POST",
        body: form,
      });
      const result = (await r.json()) as {
        error?: string;
        revision: number;
        url: string;
      };
      if (!r.ok) throw Error(result.error || "تعذّر رفع الصورة.");
      update(id, { image: result.url });
      feedback("تم رفع الصورة. اضغط حفظ التغييرات لتظهر في المتجر.");
    } catch (e) {
      feedback(e instanceof Error ? e.message : "تعذّر رفع الصورة.", true);
    } finally {
      setUploading(null);
    }
  }
  async function logout() {
    if (
      dirty &&
      !window.confirm("عندك تغييرات غير محفوظة. بدك تسجّل الخروج وتتركها؟")
    )
      return;
    try {
      const r = await fetch("/api/admin/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "logout" }),
      });
      if (!r.ok) throw Error();
      location.assign("/admin");
    } catch {
      feedback("تعذّر تسجيل الخروج، حاول مرة ثانية.", true);
    }
  }
  return (
    <div className="admin-shell">
      <header className="admin-header">
        <a href="/" className="admin-brand">
          <span className="sg-mark">SG</span>
          <span dir="ltr">Sub Gate</span>
          <small>لوحة الإدارة</small>
        </a>
        <a
          href="/"
          target="_blank"
          rel="noopener noreferrer"
          className="store-link"
        >
          عرض المتجر <ExternalLink size={16} />
        </a>
      </header>
      <main className="admin-main">
        <div className="page-heading">
          <div>
            <p className="overline">مساحتك الخاصة</p>
            <h1>إدارة متجرك</h1>
            <p>اشتراكاتك وأسعارك وعروضك، من مكان واحد.</p>
          </div>
          <span className="private-badge">خاص بمالك المتجر</span>
        </div>
        <div className="save-bar">
          <span className={dirty ? "unsaved" : "saved"}>
            {dirty ? "تغييرات غير محفوظة" : "كل التغييرات محفوظة"}
          </span>
          <Button size="lg" disabled={locked || !dirty} onClick={save}>
            {busy ? <LoaderCircle className="animate-spin" /> : <Save />}
            {busy ? "جارٍ الحفظ…" : "حفظ التغييرات"}
          </Button>
        </div>
        {message && (
          <div
            className={"notice " + (error ? "error" : "success")}
            role={error ? "alert" : "status"}
          >
            {!error && <Check size={18} />}
            <span>{message}</span>
          </div>
        )}
        <fieldset disabled={locked} className="editor-fieldset">
          <section className="settings-panel stats-panel">
            <div>
              <h2>إحصائيات المتجر</h2>
              <p>العدد التقريبي للزوار والمتصفحين الآن.</p>
            </div>
            <div className="stats-grid">
              <div>
                <b>{stats?.totalVisitors ?? "—"}</b>
                <span>إجمالي الزوار</span>
              </div>
              <div>
                <b>{stats?.activeVisitors ?? "—"}</b>
                <span>يشاهدون الموقع الآن</span>
              </div>
            </div>
          </section>
          <section className="settings-panel">
            <div>
              <h2>إعدادات المتجر</h2>
              <p>رقم الطلبات اللي بتوصله رسائل الزبائن.</p>
            </div>
            <div className="settings-fields">
              <label>
                اسم المتجر
                <Input
                  value={store.name}
                  maxLength={60}
                  onChange={(e) => setStore({ ...store, name: e.target.value })}
                />
              </label>
              <label>
                رقم واتساب الدولي
                <Input
                  dir="ltr"
                  inputMode="tel"
                  value={store.whatsapp}
                  maxLength={15}
                  onChange={(e) =>
                    setStore({
                      ...store,
                      whatsapp: e.target.value.replace(/[^0-9]/g, ""),
                    })
                  }
                />
                <small>مثال: 962787900654 — بدون + أو مسافات</small>
              </label>
            </div>
            <h3>خطوات الطلب</h3>
            {store.page.steps.map((step, index) => (
              <div className="two-fields" key={index}>
                <label>
                  عنوان الخطوة {index + 1}
                  <Input
                    value={step.title}
                    onChange={(e) =>
                      setStore({
                        ...store,
                        page: {
                          ...store.page,
                          steps: store.page.steps.map((v, i) =>
                            i === index ? { ...v, title: e.target.value } : v,
                          ),
                        },
                      })
                    }
                  />
                </label>
                <label>
                  وصف الخطوة
                  <Input
                    value={step.description}
                    onChange={(e) =>
                      setStore({
                        ...store,
                        page: {
                          ...store.page,
                          steps: store.page.steps.map((v, i) =>
                            i === index
                              ? { ...v, description: e.target.value }
                              : v,
                          ),
                        },
                      })
                    }
                  />
                </label>
              </div>
            ))}
            <h3>الأسئلة الشائعة</h3>
            {store.page.faq.map((item, index) => (
              <div className="two-fields" key={index}>
                <label>
                  السؤال
                  <Input
                    value={item.question}
                    onChange={(e) =>
                      setStore({
                        ...store,
                        page: {
                          ...store.page,
                          faq: store.page.faq.map((v, i) =>
                            i === index
                              ? { ...v, question: e.target.value }
                              : v,
                          ),
                        },
                      })
                    }
                  />
                </label>
                <label>
                  الجواب
                  <Textarea
                    value={item.answer}
                    onChange={(e) =>
                      setStore({
                        ...store,
                        page: {
                          ...store.page,
                          faq: store.page.faq.map((v, i) =>
                            i === index ? { ...v, answer: e.target.value } : v,
                          ),
                        },
                      })
                    }
                  />
                </label>
              </div>
            ))}
          </section>
          <section className="settings-panel">
            <div>
              <h2>نصوص وألوان الصفحة</h2>
              <p>تظهر للزبون مباشرة بعد الحفظ.</p>
            </div>
            <div className="settings-fields">
              <label>
                العنوان الصغير
                <Input
                  value={store.page.heroEyebrow}
                  onChange={(e) =>
                    setStore({
                      ...store,
                      page: { ...store.page, heroEyebrow: e.target.value },
                    })
                  }
                />
              </label>
              <label>
                العنوان
                <Input
                  value={store.page.heroTitle}
                  onChange={(e) =>
                    setStore({
                      ...store,
                      page: { ...store.page, heroTitle: e.target.value },
                    })
                  }
                />
              </label>
              <label>
                الكلمة الملوّنة
                <Input
                  value={store.page.heroHighlight}
                  onChange={(e) =>
                    setStore({
                      ...store,
                      page: { ...store.page, heroHighlight: e.target.value },
                    })
                  }
                />
              </label>
              <label>
                نص زر الواجهة
                <Input
                  value={store.page.heroButton}
                  onChange={(e) =>
                    setStore({
                      ...store,
                      page: { ...store.page, heroButton: e.target.value },
                    })
                  }
                />
              </label>
              <label className="bundle-details">
                رسالة الطلب
                <Textarea
                  value={store.page.orderTemplate}
                  onChange={(e) =>
                    setStore({
                      ...store,
                      page: { ...store.page, orderTemplate: e.target.value },
                    })
                  }
                />
                <small>
                  استخدم {"{التطبيق}"} و {"{الباقة}"} لإظهار اسم الاشتراك
                  تلقائياً.
                </small>
              </label>
              <label className="bundle-details">
                وصف الواجهة
                <Textarea
                  value={store.page.heroDescription}
                  onChange={(e) =>
                    setStore({
                      ...store,
                      page: { ...store.page, heroDescription: e.target.value },
                    })
                  }
                />
              </label>
              <label>
                لون الموقع الأساسي
                <Input
                  type="color"
                  value={store.page.accent}
                  onChange={(e) =>
                    setStore({
                      ...store,
                      page: { ...store.page, accent: e.target.value },
                    })
                  }
                />
              </label>
            </div>
          </section>
          <section className="catalog-editor">
            <div className="catalog-heading">
              <div>
                <h2>
                  الاشتراكات <span>{store.products.length}</span>
                </h2>
                <p>أول اشتراك ظاهر بيظهر كمان في العرض الرئيسي.</p>
              </div>
              <Button
                variant="outline"
                onClick={add}
                disabled={store.products.length >= 80}
              >
                <Plus />
                إضافة اشتراك
              </Button>
            </div>
            {store.products.length === 0 && (
              <div className="empty-catalog">
                ما في اشتراكات. اضغط «إضافة اشتراك» عشان تبدأ.
              </div>
            )}
            <Accordion type="multiple" value={opened} onValueChange={setOpened}>
              {store.products.map((p, index) => (
                <AccordionItem
                  value={p.id}
                  key={p.id}
                  className="product-editor"
                >
                  <AccordionTrigger className="product-trigger">
                    <span className="product-summary">
                      <span className="logo-box">
                        {p.image ? (
                          <img src={p.image} alt="" />
                        ) : (
                          <ImagePlus size={25} />
                        )}
                      </span>
                      <span>
                        <strong>{p.name || "اشتراك جديد"}</strong>
                        <small>
                          {p.plans.length} باقات ·{" "}
                          {p.visible ? "ظاهر في المتجر" : "مخفي"}
                        </small>
                      </span>
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="product-fields">
                    <div className="product-actions">
                      <label className="check-label">
                        <Checkbox
                          checked={p.visible}
                          onCheckedChange={(value) =>
                            update(p.id, { visible: value === true })
                          }
                        />
                        إظهار في المتجر
                      </label>
                      <div>
                        <Button
                          variant="ghost"
                          size="icon"
                          aria-label={"نقل " + p.name + " للأعلى"}
                          disabled={index === 0}
                          onClick={() => move(index, -1)}
                        >
                          <ArrowUp />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          aria-label={"نقل " + p.name + " للأسفل"}
                          disabled={index === store.products.length - 1}
                          onClick={() => move(index, 1)}
                        >
                          <ArrowDown />
                        </Button>
                        <Button
                          variant="ghost"
                          className="delete-button"
                          onClick={() => setDeleting(p.id)}
                        >
                          <Trash2 />
                          حذف
                        </Button>
                      </div>
                    </div>
                    <div className="two-fields">
                      <label>
                        اسم التطبيق
                        <Input
                          value={p.name}
                          maxLength={100}
                          onChange={(e) =>
                            update(p.id, { name: e.target.value })
                          }
                        />
                      </label>
                      <label>
                        وصف مختصر
                        <Input
                          value={p.description}
                          maxLength={240}
                          onChange={(e) =>
                            update(p.id, { description: e.target.value })
                          }
                        />
                      </label>
                    </div>
                    <div className="upload-row">
                      <label className="upload-label">
                        <ImagePlus size={18} />
                        {uploading === p.id
                          ? "جارٍ رفع الصورة…"
                          : "تغيير صورة التطبيق"}
                        <input
                          type="file"
                          accept="image/png,image/jpeg,image/webp"
                          disabled={locked}
                          onChange={(e) => {
                            void upload(p.id, e.target.files?.[0]);
                            e.target.value = "";
                          }}
                        />
                      </label>
                      <small>PNG / JPG / WebP · حتى 2 ميغابايت</small>
                      {p.image && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => update(p.id, { image: "" })}
                        >
                          إزالة الصورة
                        </Button>
                      )}
                    </div>
                    <h3>الباقات والأسعار</h3>
                    <div className="plan-edit-list">
                      {p.plans.map((v, i) => (
                        <div className="plan-edit" key={i}>
                          <label>
                            المدة / نوع الاشتراك
                            <Input
                              value={v.label}
                              maxLength={120}
                              onChange={(e) =>
                                plan(p.id, i, { label: e.target.value })
                              }
                            />
                          </label>
                          <label>
                            السعر بالدينار
                            <Input
                              type="number"
                              dir="ltr"
                              min="0.01"
                              max="100000"
                              step="0.01"
                              value={v.price || ""}
                              onChange={(e) =>
                                plan(p.id, i, { price: Number(e.target.value) })
                              }
                            />
                          </label>
                          <label>
                            السعر قبل العرض
                            <Input
                              type="number"
                              dir="ltr"
                              min="0"
                              max="100000"
                              step="0.01"
                              value={v.oldPrice || ""}
                              placeholder="اختياري"
                              onChange={(e) =>
                                plan(p.id, i, {
                                  oldPrice: Number(e.target.value) || 0,
                                })
                              }
                            />
                          </label>
                          <label>
                            ملاحظة للزبون
                            <Input
                              value={v.note}
                              maxLength={200}
                              placeholder="مثلاً: بدون ضمان"
                              onChange={(e) =>
                                plan(p.id, i, { note: e.target.value })
                              }
                            />
                          </label>
                          <Button
                            variant="ghost"
                            size="icon"
                            aria-label={"حذف باقة " + v.label}
                            disabled={p.plans.length === 1}
                            onClick={() =>
                              update(p.id, {
                                plans: p.plans.filter((_, n) => n !== i),
                              })
                            }
                          >
                            <Trash2 />
                          </Button>
                        </div>
                      ))}
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={p.plans.length >= 20}
                      onClick={() =>
                        update(p.id, {
                          plans: [
                            ...p.plans,
                            { label: "", price: 1, note: "" },
                          ],
                        })
                      }
                    >
                      <Plus />
                      إضافة باقة
                    </Button>
                    <div className="bundle-edit">
                      <label className="check-label">
                        <Checkbox
                          checked={p.bundle.enabled}
                          onCheckedChange={(value) =>
                            update(p.id, {
                              bundle: { ...p.bundle, enabled: value === true },
                            })
                          }
                        />
                        إضافة عرض خاص تحت الاشتراك
                      </label>
                      {p.bundle.enabled && (
                        <div className="bundle-fields">
                          <label>
                            عنوان العرض
                            <Input
                              value={p.bundle.label}
                              maxLength={120}
                              placeholder="إلك ولصاحبك؟ خد اشتراكين"
                              onChange={(e) =>
                                update(p.id, {
                                  bundle: {
                                    ...p.bundle,
                                    label: e.target.value,
                                  },
                                })
                              }
                            />
                          </label>
                          <label>
                            السعر بالدينار
                            <Input
                              type="number"
                              dir="ltr"
                              min="0.01"
                              step="0.01"
                              value={p.bundle.price || ""}
                              onChange={(e) =>
                                update(p.id, {
                                  bundle: {
                                    ...p.bundle,
                                    price: Number(e.target.value),
                                  },
                                })
                              }
                            />
                          </label>
                          <label>
                            السعر قبل العرض
                            <Input
                              type="number"
                              dir="ltr"
                              min="0"
                              step="0.01"
                              value={p.bundle.oldPrice || ""}
                              placeholder="اختياري"
                              onChange={(e) =>
                                update(p.id, {
                                  bundle: {
                                    ...p.bundle,
                                    oldPrice: Number(e.target.value) || 0,
                                  },
                                })
                              }
                            />
                          </label>
                          <label className="bundle-details">
                            تفاصيل العرض ورسالة الطلب
                            <Input
                              value={p.bundle.details}
                              maxLength={300}
                              placeholder="اشتراكين، كل واحد لمدة سنة"
                              onChange={(e) =>
                                update(p.id, {
                                  bundle: {
                                    ...p.bundle,
                                    details: e.target.value,
                                  },
                                })
                              }
                            />
                          </label>
                        </div>
                      )}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </section>
        </fieldset>
        <footer className="admin-footer">
          التغييرات بتظهر لكل الزوار بعد الحفظ.{" "}
          <Button variant="ghost" onClick={logout}>
            تسجيل الخروج
          </Button>
        </footer>
      </main>
      <AlertDialog
        open={deleting !== null}
        onOpenChange={(open) => {
          if (!open) setDeleting(null);
        }}
      >
        <AlertDialogContent dir="rtl">
          <AlertDialogTitle>حذف الاشتراك؟</AlertDialogTitle>
          <AlertDialogDescription>
            رح ينحذف «{store.products.find((p) => p.id === deleting)?.name}» مع
            باقاته من القائمة. التغيير بيصير ظاهر بعد الحفظ.
          </AlertDialogDescription>
          <AlertDialogFooter>
            <AlertDialogCancel>تراجع</AlertDialogCancel>
            <AlertDialogAction
              variant="destructive"
              onClick={() => {
                setStore((s) => ({
                  ...s,
                  products: s.products.filter((p) => p.id !== deleting),
                }));
                setDeleting(null);
              }}
            >
              حذف الاشتراك
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
