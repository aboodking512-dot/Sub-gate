import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'Sub Gate | لوحة الإدارة',description:'إدارة اشتراكات وعروض Sub Gate',robots:{index:false,follow:false},icons:{icon:'/assets/sasa-subs-logo.png',shortcut:'/assets/sasa-subs-logo.png'}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="ar" dir="rtl"><head><link rel="preconnect" href="https://fonts.googleapis.com"/><link href="https://fonts.googleapis.com/css2?family=Readex+Pro:wght@400;500;600;700&display=swap" rel="stylesheet"/></head><body>{children}</body></html>}
