import { recordVisit, readSiteStats } from "@/lib/site-stats";

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => null);
    const visitorId = typeof body?.visitorId === "string" ? body.visitorId : "";
    if (!/^[a-f0-9-]{36}$/i.test(visitorId))
      return Response.json({ error: "بيانات غير صالحة" }, { status: 400 });
    await recordVisit(visitorId);
    return Response.json(await readSiteStats(), {
      headers: { "Cache-Control": "no-store" },
    });
  } catch (error) {
    console.error("visit tracking unavailable", error);
    return new Response(null, { status: 204 });
  }
}
