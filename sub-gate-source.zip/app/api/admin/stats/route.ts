import { isOwner } from "@/lib/admin-auth";
import { readSiteStats } from "@/lib/site-stats";

export async function GET() {
  if (!(await isOwner()))
    return Response.json({ error: "غير مصرح" }, { status: 403 });
  try {
    return Response.json(await readSiteStats(), {
      headers: { "Cache-Control": "no-store" },
    });
  } catch (error) {
    console.error("stats unavailable", error);
    return Response.json({ error: "تعذّر تحميل الإحصائيات" }, { status: 503 });
  }
}
