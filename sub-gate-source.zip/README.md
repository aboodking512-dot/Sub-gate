# Sub Gate — independent Cloudflare deployment

Private owner dashboard and public Arabic storefront. This checkout has no Sites identity or ChatGPT sign-in dependency.

## Cloudflare resources

Create D1 `sub-gate-db` and R2 `sub-gate-images` in your own account. Add the D1 ID as build environment variable `SUBGATE_DATABASE_ID`. R2 activation may require billing setup; review any billing prompt yourself.

Connect the private GitHub repository to Workers Builds. Use `pnpm run build` as build command and `pnpm run deploy` as deploy command. Deployment refuses an unconfigured D1 ID, applies schema migrations, then deploys the Worker.

Set runtime secret `ADMIN_SETUP_HASH` and runtime variable `ADMIN_SETUP_EXPIRES` in your Cloudflare Worker. Generate a fresh one-time setup token, retain it privately, store its SHA-256 hash, and set expiry in Unix milliseconds. Visit `/admin/setup#token=YOUR_TOKEN` to choose owner credentials. Do not put the token or a password in GitHub files or Cloudflare build logs.

## Migration data

Source code is not a backup of live data. Export the current `storefront` row and uploaded image objects before cutover, import the row into the destination D1, and copy images under their unchanged object keys to destination R2. Do not transfer active login sessions. Set up the destination owner account using the private enrollment link.

Keep the old site running until catalog, prices, images, login, edit persistence, logout, and WhatsApp links pass verification on the new URL. Then replace the public link on Facebook. A purchased domain is optional.

## Local checks

`node tests/integration.mjs` checks database, catalog, authentication, and uploads. Dependencies use the checked-in pnpm lockfile.
