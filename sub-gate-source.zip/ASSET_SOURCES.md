# Application logos

Existing trademarks sourced from Wikimedia Commons.

- Canva: https://commons.wikimedia.org/wiki/File:Canva_logo.svg
- Gemini: https://commons.wikimedia.org/wiki/File:Google-gemini-icon.svg
- CapCut: https://commons.wikimedia.org/wiki/File:Capcut-icon.svg
- Shahid: https://commons.wikimedia.org/wiki/File:Mbc_Shahid_logo.svg
- Prime Video: https://commons.wikimedia.org/wiki/File:Prime_Video_logo_(2024).svg
