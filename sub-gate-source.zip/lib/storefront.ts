import template from "@/app/storefront-template";
import type { Store, Product } from "./store-model";
export const escapeHtml = (v: unknown) =>
  String(v).replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ]!,
  );
function order(s: Store, message: string) {
  return `href="https://wa.me/${s.whatsapp}?text=${encodeURIComponent(message)}" target="_blank" rel="noopener noreferrer"`;
}
function productCard(s: Store, p: Product) {
  const e = escapeHtml;
  const msg = (plan: string) =>
    s.page.orderTemplate
      .replaceAll("{التطبيق}", p.name)
      .replaceAll("{الباقة}", plan);
  const image = p.image
    ? `<div class="app-icon brand-tile"><img src="${e(p.image)}" alt="" width="66" height="40"></div>`
    : `<div class="app-icon" aria-hidden="true">${e(p.name.slice(0, 1))}</div>`;
  const cost = (price: number, oldPrice: number) =>
    `<span class="plan-cost">${oldPrice > price ? `<del dir="ltr">${oldPrice}</del>` : ""}<b dir="ltr">${price}</b><small>د.أ</small><span aria-hidden="true">↗</span></span>`;
  return `<article class="card product-card">${image}<h3>${e(p.name)}</h3><p class="sub">${e(p.description)}</p><div class="plan-options">${p.plans.map((plan) => `<a class="plan-option" ${order(s, msg(plan.label))}><span class="plan-description"><span>${e(plan.label)}</span>${plan.note ? `<small class="plan-note">${e(plan.note)}</small>` : ""}</span>${cost(plan.price, plan.oldPrice)}</a>`).join("")}</div>${p.bundle.enabled ? `<div class="bundle-offer"><p>${e(p.bundle.label)}</p><a ${order(s, msg(p.bundle.label))}>${p.bundle.oldPrice > p.bundle.price ? `<del dir="ltr">${p.bundle.oldPrice}</del> ` : ""}بسعر <strong>${p.bundle.price} دنانير</strong> ←</a><small>${e(p.bundle.details)}</small></div>` : ""}</article>`;
}
export function renderStorefront(s: Store) {
  let html = template;
  const e = escapeHtml;
  const products = s.products.filter((p) => p.visible);
  const cards = products.length
    ? products.map((p) => productCard(s, p)).join("")
    : "<p>حالياً ما في اشتراكات معروضة. تواصل معنا للاستفسار.</p>";
  const start = html.indexOf('<div class="cards">');
  const end = html.indexOf("</section></main></div>", start);
  html =
    html.slice(0, start) +
    '<div class="cards">' +
    cards +
    "</div>" +
    html.slice(end);
  const heroStart = html.indexOf('<div class="offer">');
  const heroEnd = html.indexOf('<div class="band">', heroStart);
  const p = products[0];
  const hero = p
    ? `<div class="offer"><div class="offer-head">${p.image ? `<span class="hero-brand"><img src="${e(p.image)}" alt="${e(p.name)}" width="100" height="45"></span>` : `<b>${e(p.name)}</b>`}<span class="tag">SUB GATE</span></div><h2>${e(p.name)}</h2><p>${e(p.description)}</p><div class="offer-price"><strong>${p.plans[0].price}</strong><span>دينار أردني<br><small>${e(p.plans[0].label)}</small></span></div>${p.bundle.enabled ? `<div class="hero-bundle">${e(p.bundle.label)} — بـ ${p.bundle.price} دنانير</div>` : ""}<div class="offer-bottom"><span>${e(p.plans[0].note || p.plans[0].label)}</span><a href="#plans">شوف الباقات ←</a></div></div>`
    : '<div class="offer"><h2>شو الاشتراك اللي ببالك؟</h2><p>احكِ معنا على واتساب للاستفسار.</p></div>';
  html = html.slice(0, heroStart) + hero + "</div>" + html.slice(heroEnd);
  html = html
    .replaceAll("Sub Gate", e(s.name))
    .replaceAll("962787900654", s.whatsapp)
    .replace("078 790 0654 ↗", e("+" + s.whatsapp) + " ↗");
  const page = s.page;
  html = html
    .replace("عالم تطبيقاتك، أقرب إلك", e(page.heroEyebrow))
    .replace(
      "اشتراكاتك المفضّلة.<br><em>بسعر بحبّك.</em>",
      `${e(page.heroTitle)}<br><em>${e(page.heroHighlight)}</em>`,
    )
    .replace(
      "خلّي أفكارك تاخد مساحتها. اختار اشتراكك، ابعتلنا على واتساب، ونتابع معك تفاصيل التفعيل.",
      e(page.heroDescription),
    )
    .replace(
      'شوف الاشتراكات <span aria-hidden="true">←</span>',
      `${e(page.heroButton)} <span aria-hidden="true">←</span>`,
    );
  html = html.replace(
    /<div class="steps">(?:<div class="step">[\s\S]*?<\/div>){3}<\/div>/,
    `<div class="steps">${page.steps.map((step, index) => `<div class="step"><span class="num">0${index + 1}</span><h3>${e(step.title)}</h3><p>${e(step.description)}</p></div>`).join("")}</div>`,
  );
  html = html.replace(
    /<section id="faq" class="faq">[\s\S]*?<\/section>/,
    `<section id="faq" class="faq"><h2>ممكن تكون عم تسأل…</h2>${page.faq.map((item) => `<details><summary>${e(item.question)}</summary><p>${e(item.answer)}</p></details>`).join("")}</section>`,
  );
  html = html
    .replace(
      /<details><summary>التفعيل على إيميلي الشخصي\؟<\/summary>.*?<\/details>/,
      "<details><summary>كيف بعرف تفاصيل التفعيل؟</summary><p>شوف نوع الاشتراك والملاحظات تحت كل باقة. بنأكد معك التفاصيل على واتساب قبل الدفع.</p></details>",
    )
    .replace(
      /<details><summary>في اشتراكات لتطبيقات ثانية\؟<\/summary>.*?<\/details>/,
      "<details><summary>في اشتراكات لتطبيقات ثانية؟</summary><p>شوف الاشتراكات المعروضة، أو ابعتلنا اسم التطبيق اللي بدك إياه وبنأكدلك التوفر والسعر.</p></details>",
    );
  html = html
    .replace("</style>", `:root{--accent:${page.accent}}</style>`)
    .replace(
      "</style>",
      '.hero-bundle{margin:0 0 20px;padding:12px;border-radius:10px;background:var(--panel);font-size:14px}.offer-price strong{font-size:clamp(38px,6vw,72px);letter-spacing:-2px}.offer-price{flex-wrap:wrap}.offer h2,.product-card h3,.plan-description{overflow-wrap:anywhere}.admin-link{font-size:13px;color:var(--muted)}.site-brand-logo{width:184px;height:52px;object-fit:contain;display:block}.site-brand-logo-dark{display:none}html[data-theme="dark"] .site-brand-logo-light{display:none}html[data-theme="dark"] .site-brand-logo-dark{display:block}.plan-cost del,.bundle-offer del{font-size:14px;color:#c43a3a;text-decoration:line-through 2px #dc2626;margin-inline-end:2px}.live-visitors{font-size:12px;color:var(--muted);white-space:nowrap}.live-visitors b{color:var(--accent);font-size:14px}</style>',
    );
  html = html.replace(
    /<link rel="icon" href="[^"]+">/,
    '<link rel="icon" type="image/png" href="/assets/sasa-subs-icon-dark-mint.png">',
  );
  html = html.replace(
    /<a href="#" class="logo" aria-label="[^"]+، الرئيسية">[\s\S]*?<\/a>/,
    '<a href="#" class="logo" aria-label="Sasa Subs، الرئيسية"><img class="site-brand-logo site-brand-logo-light" src="/assets/sasa-subs-logo-horizontal.png" alt="Sasa Subs"><img class="site-brand-logo site-brand-logo-dark" src="/assets/sasa-subs-logo-dark.png" alt="Sasa Subs"></a>',
  );
  html = html.replace(
    '<div class="nav-actions">',
    '<div class="nav-actions"><span class="live-visitors" aria-live="polite">يشاهد الآن <b id="live-visitors">—</b></span>',
  );
  html = html.replace(
    "</footer>",
    '<div style="margin-top:16px;text-align:center"><a class="admin-link" href="/admin">إدارة المتجر</a></div></footer>',
  );
  const tracking =
    'const visitorKey="sasa-subs-visitor";let visitorId="";try{visitorId=localStorage.getItem(visitorKey)||crypto.randomUUID();localStorage.setItem(visitorKey,visitorId)}catch(e){};async function pingVisitors(){if(!visitorId)return;try{const response=await fetch("/api/stats",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({visitorId})});const stats=await response.json();const target=document.getElementById("live-visitors");if(target&&typeof stats.activeVisitors==="number")target.textContent=String(stats.activeVisitors)}catch(e){}}pingVisitors();setInterval(pingVisitors,30000);';
  const lastScript = html.lastIndexOf("</script>");
  html = html.slice(0, lastScript) + tracking + html.slice(lastScript);
  return html;
}
