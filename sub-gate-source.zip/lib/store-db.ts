import { env } from 'cloudflare:workers';
import { seed } from './seed';
import { storeSchema, type Store } from './store-model';
export function database(){if(!env.DB)throw new Error('Store database unavailable');return env.DB;}
export async function readStore(){const row=await database().prepare('SELECT document, revision FROM storefront WHERE id = ?').bind('main').first<{document:string,revision:number}>();return row?{store:storeSchema.parse(JSON.parse(row.document)),revision:row.revision}:{store:structuredClone(seed),revision:0};}
export async function writeStore(store:Store, revision:number){const db=database();const doc=JSON.stringify(store);const now=new Date().toISOString();const result=revision===0?await db.prepare('INSERT OR IGNORE INTO storefront (id, document, revision, updated_at) VALUES (?, ?, ?, ?)').bind('main',doc,1,now).run():await db.prepare('UPDATE storefront SET document = ?, revision = revision + 1, updated_at = ? WHERE id = ? AND revision = ?').bind(doc,now,'main',revision).run();return result.meta.changes===1;}
