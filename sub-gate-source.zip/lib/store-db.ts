import { env } from "cloudflare:workers";
import { seed } from "./seed";
import { defaultPageText, storeSchema, type Store } from "./store-model";
export function database() {
  if (!env.DB) throw new Error("Store database unavailable");
  return env.DB;
}
function normalizeLegacyStore(value: unknown) {
  if (!value || typeof value !== "object") return value;
  const store = value as { page?: unknown; products?: unknown };
  const page = store.page && typeof store.page === "object" ? store.page : {};
  const products = Array.isArray(store.products)
    ? store.products.map((product) => {
        if (!product || typeof product !== "object") return product;
        const item = product as { plans?: unknown; bundle?: unknown };
        return {
          ...item,
          plans: Array.isArray(item.plans)
            ? item.plans.map((plan) =>
                plan && typeof plan === "object"
                  ? { oldPrice: 0, ...plan }
                  : plan,
              )
            : item.plans,
          bundle:
            item.bundle && typeof item.bundle === "object"
              ? { oldPrice: 0, ...item.bundle }
              : item.bundle,
        };
      })
    : store.products;
  return { ...store, products, page: { ...defaultPageText, ...page } };
}
export async function readStore() {
  const row = await database()
    .prepare("SELECT document, revision FROM storefront WHERE id = ?")
    .bind("main")
    .first<{ document: string; revision: number }>();
  return row
    ? {
        store: storeSchema.parse(
          normalizeLegacyStore(JSON.parse(row.document)),
        ),
        revision: row.revision,
      }
    : { store: structuredClone(seed), revision: 0 };
}
export async function writeStore(store: Store, revision: number) {
  const db = database();
  const doc = JSON.stringify(store);
  const now = new Date().toISOString();
  const result =
    revision === 0
      ? await db
          .prepare(
            "INSERT OR IGNORE INTO storefront (id, document, revision, updated_at) VALUES (?, ?, ?, ?)",
          )
          .bind("main", doc, 1, now)
          .run()
      : await db
          .prepare(
            "UPDATE storefront SET document = ?, revision = revision + 1, updated_at = ? WHERE id = ? AND revision = ?",
          )
          .bind(doc, now, "main", revision)
          .run();
  return result.meta.changes === 1;
}
