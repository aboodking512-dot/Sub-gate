import {scrypt,randomBytes,createHash,timingSafeEqual} from 'node:crypto';
import {env} from 'cloudflare:workers';
import {database} from './store-db';
export const COOKIE='__Host-subgate_admin';
export const sha256=(value:string)=>createHash('sha256').update(value).digest('hex');
const derive=(password:string,salt:string)=>new Promise<Buffer>((resolve,reject)=>scrypt(password,salt,32,{N:16384,r:8,p:5,maxmem:32*1024*1024},(e,key)=>e?reject(e):resolve(key)));
export async function hashPassword(password:string){const salt=randomBytes(16).toString('hex');return 'scrypt-v1$'+salt+'$'+(await derive(password,salt)).toString('hex');}
export async function verifyPassword(password:string,encoded:string){const [version,salt,hash]=encoded.split('$');if(version!=='scrypt-v1'||!salt||!/^[a-f0-9]{64}$/.test(hash||''))return false;return timingSafeEqual(await derive(password,salt),Buffer.from(hash,'hex'));}
export async function account(){return database().prepare('SELECT username, password_hash FROM admin_account WHERE id = ?').bind('owner').first<{username:string,password_hash:string}>();}
export function sessionToken(cookie:string|null){return cookie?.split(';').map(x=>x.trim()).find(x=>x.startsWith(COOKIE+'='))?.slice(COOKIE.length+1)||'';}
export async function validSession(cookie:string|null){const token=sessionToken(cookie);if(!/^[a-f0-9]{64}$/.test(token))return false;return Boolean(await database().prepare('SELECT token_hash FROM admin_sessions WHERE token_hash = ? AND expires_at > ?').bind(sha256(token),Date.now()).first());}
export async function createSession(){const token=randomBytes(32).toString('hex');const db=database();await db.prepare('DELETE FROM admin_sessions WHERE expires_at <= ?').bind(Date.now()).run();await db.prepare('INSERT INTO admin_sessions (token_hash, expires_at) VALUES (?, ?)').bind(sha256(token),Date.now()+86400000).run();return `${COOKIE}=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=86400`;}
export async function revokeSession(cookie:string|null){const token=sessionToken(cookie);if(token)await database().prepare('DELETE FROM admin_sessions WHERE token_hash = ?').bind(sha256(token)).run();return `${COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`;}
export function sameOrigin(request:Request){return request.headers.get('origin')===new URL(request.url).origin&&request.headers.get('sec-fetch-site')!=='cross-site';}
async function attempt(key:string,limit:number){const now=Date.now();const result=await database().prepare('INSERT INTO auth_limits (key, count, window_end) VALUES (?, 1, ?) ON CONFLICT(key) DO UPDATE SET count = CASE WHEN window_end <= ? THEN 1 ELSE count + 1 END, window_end = CASE WHEN window_end <= ? THEN excluded.window_end ELSE window_end END RETURNING count').bind(key,now+900000,now,now).first<{count:number}>();return Boolean(result&&result.count<=limit);}
export async function rateAllowed(request:Request){const ip=request.headers.get('cf-connecting-ip')||'unknown';if(!await attempt('ip:'+sha256(ip),8))return false;return attempt('global',60);}
export function setupAllowed(token:string){const expected=env.ADMIN_SETUP_HASH;const expiry=Number(env.ADMIN_SETUP_EXPIRES);return Boolean(expected&&/^[a-f0-9]{64}$/.test(expected)&&expiry>Date.now()&&/^[a-f0-9]{64}$/.test(token)&&timingSafeEqual(Buffer.from(sha256(token),'hex'),Buffer.from(expected,'hex')));}
