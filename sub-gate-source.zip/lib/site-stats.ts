import { env } from "cloudflare:workers";

const ACTIVE_WINDOW_MS = 90_000;

function database() {
  if (!env.DB) throw new Error("Store database unavailable");
  return env.DB;
}

export async function recordVisit(visitorId: string) {
  const now = Date.now();
  const db = database();
  await db.batch([
    db
      .prepare(
        "INSERT OR IGNORE INTO site_visitors (visitor_id, first_seen, last_seen) VALUES (?, ?, ?)",
      )
      .bind(visitorId, now, now),
    db
      .prepare("UPDATE site_visitors SET last_seen = ? WHERE visitor_id = ?")
      .bind(now, visitorId),
  ]);
}

export async function readSiteStats() {
  const db = database();
  const now = Date.now();
  const [total, active] = await db.batch([
    db.prepare("SELECT COUNT(*) AS count FROM site_visitors"),
    db
      .prepare(
        "SELECT COUNT(*) AS count FROM site_visitors WHERE last_seen >= ?",
      )
      .bind(now - ACTIVE_WINDOW_MS),
  ]);
  return {
    totalVisitors: Number(
      (total.results?.[0] as { count?: number } | undefined)?.count ?? 0,
    ),
    activeVisitors: Number(
      (active.results?.[0] as { count?: number } | undefined)?.count ?? 0,
    ),
  };
}
