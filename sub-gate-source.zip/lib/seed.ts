import { defaultPageText, type Store } from "./store-model";
export const seed: Store = {
  name: "Sub Gate",
  whatsapp: "962787900654",
  products: [
    {
      id: "canva",
      name: "Canva Pro",
      description: "تفعيل على إيميلك الشخصي",
      image: "/assets/canva.svg",
      plans: [{ label: "سنة كاملة", price: 2, oldPrice: 0, note: "" }],
      bundle: {
        enabled: true,
        label: "إلك ولصاحبك؟ خد اشتراكين",
        price: 3,
        oldPrice: 0,
        details: "اشتراكين، كل اشتراك لمدة سنة، على الإيميلات الشخصية",
      },
      visible: true,
    },
    {
      id: "gemini",
      name: "جيميناي برو",
      description: "اختار المدة وطريقة التفعيل",
      image: "/assets/gemini.svg",
      plans: [
        { label: "شهر — دعوة عائلة", price: 2.5, oldPrice: 0, note: "" },
        { label: "3 شهور — دعوة عائلة", price: 7, oldPrice: 0, note: "" },
        {
          label: "رابط تفعيل 18 شهر",
          price: 3.5,
          oldPrice: 0,
          note: "بدون ضمان",
        },
      ],
      bundle: { enabled: false, label: "", price: 0, oldPrice: 0, details: "" },
      visible: true,
    },
    {
      id: "capcut",
      name: "كاب كت برو / تيمز",
      description: "اختار مدة اشتراكك",
      image: "/assets/capcut.svg",
      plans: [
        { label: "أسبوع", price: 1, oldPrice: 0, note: "" },
        { label: "شهر", price: 3, oldPrice: 0, note: "" },
      ],
      bundle: { enabled: false, label: "", price: 0, oldPrice: 0, details: "" },
      visible: true,
    },
    {
      id: "shahid",
      name: "شاهد.نت",
      description: "للمسلسلات والأفلام",
      image: "/assets/shahid.svg",
      plans: [{ label: "مشترك / ملف خاص", price: 2, oldPrice: 0, note: "" }],
      bundle: { enabled: false, label: "", price: 0, oldPrice: 0, details: "" },
      visible: true,
    },
    {
      id: "prime-video",
      name: "برايم فيديو",
      description: "اشتراك لمدة شهر — اختار النوع",
      image: "/assets/prime-video.svg",
      plans: [
        { label: "خاص — شهر", price: 4, oldPrice: 0, note: "" },
        { label: "مشترك — شهر", price: 1.6, oldPrice: 0, note: "" },
      ],
      bundle: { enabled: false, label: "", price: 0, oldPrice: 0, details: "" },
      visible: true,
    },
  ],
  page: defaultPageText,
};
