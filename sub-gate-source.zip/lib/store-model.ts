import { z } from "zod";
const text = (max: number) => z.string().trim().max(max);
export const productSchema = z
  .object({
    id: z.string().regex(/^[a-z0-9-]{1,64}$/),
    name: text(100).min(1),
    description: text(240),
    visible: z.boolean(),
    image: z
      .string()
      .regex(/^(|\/assets\/[a-z0-9-]+\.svg|\/api\/images\/[a-f0-9-]{36})$/),
    plans: z
      .array(
        z.object({
          label: text(120).min(1),
          price: z.number().finite().min(0.01).max(100000).multipleOf(0.01),
          oldPrice: z
            .number()
            .finite()
            .min(0)
            .max(100000)
            .multipleOf(0.01)
            .default(0),
          note: text(200),
        }),
      )
      .min(1)
      .max(20),
    bundle: z.object({
      enabled: z.boolean(),
      label: text(120),
      price: z.number().finite().min(0).max(100000).multipleOf(0.01),
      oldPrice: z
        .number()
        .finite()
        .min(0)
        .max(100000)
        .multipleOf(0.01)
        .default(0),
      details: text(300),
    }),
  })
  .superRefine((p, c) => {
    if (
      p.bundle.enabled &&
      (!p.bundle.label || p.bundle.price <= 0 || !p.bundle.details)
    )
      c.addIssue({
        code: "custom",
        message: "أكمل عنوان العرض وتفاصيله وسعره.",
      });
    if (
      p.plans.some((plan) => plan.oldPrice > 0 && plan.oldPrice <= plan.price)
    )
      c.addIssue({
        code: "custom",
        message: "السعر القديم لازم يكون أعلى من سعر العرض.",
      });
    if (p.bundle.oldPrice > 0 && p.bundle.oldPrice <= p.bundle.price)
      c.addIssue({
        code: "custom",
        message: "السعر القديم للعرض لازم يكون أعلى من سعر العرض.",
      });
  });
const pageTextSchema = z.object({
  heroEyebrow: text(100),
  heroTitle: text(120),
  heroHighlight: text(120),
  heroDescription: text(300),
  heroButton: text(80),
  orderTemplate: text(240).default("مرحبا، بدي {التطبيق} — {الباقة}"),
  steps: z
    .array(z.object({ title: text(100), description: text(240) }))
    .length(3),
  faq: z
    .array(z.object({ question: text(160), answer: text(500) }))
    .min(1)
    .max(8),
  accent: z.string().regex(/^#[0-9a-fA-F]{6}$/),
});
export const defaultPageText = {
  heroEyebrow: "عالم تطبيقاتك، أقرب إلك",
  heroTitle: "اشتراكاتك المفضّلة.",
  heroHighlight: "بسعر بحبّك.",
  heroDescription:
    "خلّي أفكارك تاخد مساحتها. اختار اشتراكك، ابعتلنا على واتساب، ونتابع معك تفاصيل التفعيل.",
  heroButton: "شوف الاشتراكات",
  orderTemplate: "مرحبا، بدي {التطبيق} — {الباقة}",
  steps: [
    {
      title: "اختار اللي بناسبك",
      description: "شوف العروض واختار الاشتراك والمدة المناسبة لإلك.",
    },
    {
      title: "ابعتلنا رسالة",
      description: "زر الطلب بيفتح واتساب برسالة فيها العرض اللي اخترته.",
    },
    {
      title: "كمّل طلبك معنا",
      description:
        "بنأكد تفاصيل الاشتراك وطريقة الدفع وموعد التفعيل قبل إتمام الطلب.",
    },
  ],
  faq: [
    {
      question: "كيف بطلب الاشتراك؟",
      answer:
        "اضغط زر الطلب تحت العرض المناسب. رح يفتح واتساب برسالة جاهزة، وابعتها إلنا عشان نتابع طلبك.",
    },
    {
      question: "التفعيل على إيميلي الشخصي؟",
      answer: "بنوضحلك طريقة التفعيل وتفاصيل الخطة على واتساب قبل الدفع.",
    },
    {
      question: "كيف بدفع ومتى بتفعّلوا الاشتراك؟",
      answer:
        "بنحدد معك طريقة الدفع ووقت التفعيل خلال المحادثة، قبل إتمام الطلب.",
    },
    {
      question: "في اشتراكات لتطبيقات ثانية؟",
      answer: "ابعتلنا اسم التطبيق وبنخبرك عن التوفر والسعر.",
    },
  ],
  accent: "#79edbf",
};
export const storeSchema = z
  .object({
    name: text(60).min(1),
    whatsapp: z.string().regex(/^[1-9][0-9]{7,14}$/),
    products: z.array(productSchema).max(80),
    page: pageTextSchema.default(defaultPageText),
  })
  .superRefine((s, c) => {
    if (new Set(s.products.map((p) => p.id)).size !== s.products.length)
      c.addIssue({ code: "custom", message: "معرّف اشتراك مكرر." });
  });
export type Store = z.infer<typeof storeSchema>;
export type Product = z.infer<typeof productSchema>;
export const saveSchema = z.object({
  revision: z.number().int().nonnegative(),
  store: storeSchema,
});
