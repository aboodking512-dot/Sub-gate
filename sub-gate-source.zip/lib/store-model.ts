import { z } from 'zod';
const text = (max: number) => z.string().trim().max(max);
export const productSchema = z.object({
 id:z.string().regex(/^[a-z0-9-]{1,64}$/), name:text(100).min(1), description:text(240), visible:z.boolean(),
 image:z.string().regex(/^(|\/assets\/[a-z0-9-]+\.svg|\/api\/images\/[a-f0-9-]{36})$/),
 plans:z.array(z.object({label:text(120).min(1),price:z.number().finite().min(0.01).max(100000).multipleOf(0.01),note:text(200)})).min(1).max(20),
 bundle:z.object({enabled:z.boolean(),label:text(120),price:z.number().finite().min(0).max(100000).multipleOf(0.01),details:text(300)})
}).superRefine((p,c)=>{if(p.bundle.enabled && (!p.bundle.label || p.bundle.price<=0 || !p.bundle.details))c.addIssue({code:'custom',message:'أكمل عنوان العرض وتفاصيله وسعره.'});});
export const storeSchema=z.object({name:text(60).min(1),whatsapp:z.string().regex(/^[1-9][0-9]{7,14}$/),products:z.array(productSchema).max(80)}).superRefine((s,c)=>{if(new Set(s.products.map(p=>p.id)).size!==s.products.length)c.addIssue({code:'custom',message:'معرّف اشتراك مكرر.'});});
export type Store=z.infer<typeof storeSchema>;
export type Product=z.infer<typeof productSchema>;
export const saveSchema=z.object({revision:z.number().int().nonnegative(),store:storeSchema});
