import {headers} from 'next/headers';
import {validSession,sameOrigin} from './password-auth';
export async function isOwner(){return validSession((await headers()).get('cookie'));}
export async function guardWrite(request:Request){if(!await isOwner())return Response.json({error:'سجّل الدخول بحساب إدارة المتجر أولاً.'},{status:403});if(!sameOrigin(request))return Response.json({error:'طلب غير مسموح.'},{status:403});return null;}
