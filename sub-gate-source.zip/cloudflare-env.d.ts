declare namespace Cloudflare { interface Env { DB?: D1Database; BUCKET?: R2Bucket; ADMIN_SETUP_HASH?:string; ADMIN_SETUP_EXPIRES?:string; } }
