import vinext from "vinext";
import {resolve} from "node:path";
import {defineConfig} from "vite";
import {cloudflare} from "@cloudflare/vite-plugin";
const databaseId=process.env.SUBGATE_DATABASE_ID || "00000000-0000-4000-8000-000000000000";
export default defineConfig({plugins:[vinext(),cloudflare({viteEnvironment:{name:"rsc",childEnvironments:["ssr"]},inspectorPort:false,config:{name:"sub-gate",main:"vinext/server/fetch-handler",compatibility_date:"2026-05-15",compatibility_flags:["nodejs_compat"],workers_dev:true,d1_databases:[{binding:"DB",database_name:"sub-gate-db",database_id:databaseId,migrations_dir:resolve("drizzle")}],r2_buckets:[{binding:"BUCKET",bucket_name:"sub-gate-images"}]}})]});
